package com.verizon.producerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
