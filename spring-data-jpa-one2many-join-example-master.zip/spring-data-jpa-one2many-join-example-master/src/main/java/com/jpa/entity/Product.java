package com.jpa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="product_o2o")
public class Product {
    @Id
    private int pid;
    private String productName;
    private int qty;
    private int price;
//    @ManyToOne(mappedBy="product")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cid")
    Customer customer;
}
