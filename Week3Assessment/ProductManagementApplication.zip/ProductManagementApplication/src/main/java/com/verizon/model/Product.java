package com.verizon.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity

public class Product {
	@Id
	Integer pid;
	@Column
	String pname;
	Integer price;
	
	

}
