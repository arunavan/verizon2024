package com.adp.springbootbasicauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBasicAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBasicAuthenticationApplication.class, args);
	}
}
