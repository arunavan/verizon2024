package com.adp.springbootbasicauthentication.Controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {

	//all
    @GetMapping("/public")
    public String HelloPublic() {

        return "Hello Public!";
    }
//user,admin
    @PreAuthorize("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
    @GetMapping("/private")
    public String HelloPrivate() {

        return "Hello Private!";
    }
//admin
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/admin")
    public String HelloAdmin() {

        return "Hello Admin!";
    }
}
