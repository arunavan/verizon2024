//package com.adp.spring.config;
//
//import org.springframework.cloud.gateway.route.RouteLocator;
//import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class GateWayConfiguration {
//	
//	@Bean
//	public RouteLocator getLocators(RouteLocatorBuilder builder) {
//		return builder.routes()
//					  .route(p -> p.path("/helloc/**").uri("lb://HELLO-CONSUMER/helloc"))
//					  .route(p -> p.path("/hellop/**").uri("lb://HELLO-PRODUCER/hellop"))
//					  .build();
//	}
//}