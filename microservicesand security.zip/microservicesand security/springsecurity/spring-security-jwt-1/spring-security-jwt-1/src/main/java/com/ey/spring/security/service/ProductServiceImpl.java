package com.ey.spring.security.service;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ey.spring.security.dto.Product;
import com.ey.spring.security.entity.UserInfo;
import com.ey.spring.security.repository.UserInfoRepository;



@Service(value = "productService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	private List<Product> productList;

	@PostConstruct
	public void loadProductsFromDB() {
		productList = Arrays.asList(new Product(101,"bag01",50,999.99),
				new Product(102,"bag102",50,999.99));

	}
	
	public List<Product> getAllProducts() {
		return productList;
	}
	
	
	public Product getProductById(int id) {
		try {
			return productList.stream().filter(p->p.getProductId()==id)
					.findAny().orElseThrow(()->new Exception("Product Id Invalid"));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String addUser(UserInfo userInfo) {
		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
		userInfo.setPassword(encoder.encode(userInfo.getPassword()));
		userInfo.setRoles("ROLE"+"_"+ userInfo.getRoles());
		userInfoRepository.save(userInfo);
		return "user added to database";
	}
}
