package com.ey.spring.security.service;

import java.util.List;

import com.ey.spring.security.dto.Product;
import com.ey.spring.security.entity.UserInfo;

public interface ProductService {
	public void loadProductsFromDB();
	public List<Product> getAllProducts();
	public Product getProductById(int id);
	
	public String addUser(UserInfo userInfo);
}