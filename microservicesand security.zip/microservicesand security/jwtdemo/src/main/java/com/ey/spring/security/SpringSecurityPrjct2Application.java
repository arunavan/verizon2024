package com.ey.spring.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// http://localhost:8082/login

@SpringBootApplication
public class SpringSecurityPrjct2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityPrjct2Application.class, args);
	}

}
