package com.adp.spring.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adp.spring.dto.Employee;
import com.adp.spring.entity.EmployeeEntity;
import com.adp.spring.exception.EmployeeException;
import com.adp.spring.repository.EmployeeRepository;



//@Slf4j  Applying Spring AOP for logging
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public Employee getEmployeeById(Long id) throws EmployeeException {
		try {
			Optional<EmployeeEntity> employeeEntity= employeeRepository.findById(id);
			
			if(employeeEntity.isPresent()) {
				Employee employee= modelMapper.map(employeeEntity, Employee.class);
				return employee;
			}else {
				throw new EmployeeException("Invalid Employee Id");
			}
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public Employee getEmployeeByName(String name) throws EmployeeException {
		try {
			EmployeeEntity employeeEntity= employeeRepository.findByName(name).get();
			return modelMapper.map(employeeEntity,Employee.class);
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			List<EmployeeEntity> employeeList= employeeRepository.findAll();
			if(employeeList.size()!=0) {
				List<Employee> empList = new ArrayList<>();
				employeeList.forEach(employee -> 
					empList.add(modelMapper.map(employee, Employee.class)));
				return empList;
			}else {
				throw new EmployeeException("No employees in the database");			
			}
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public boolean exists(String name) throws EmployeeException {
		if(employeeRepository.findByName(name)!=null) {
			return true;
		}
		return false;
	}

	@Override
	public Employee save(Employee employee) throws EmployeeException {
		try {
			EmployeeEntity employeeEntity = modelMapper.map(employee, EmployeeEntity.class);
			EmployeeEntity employeeEntityReturn = employeeRepository.save(employeeEntity);
			return modelMapper.map(employeeEntityReturn, Employee.class);
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public List<Employee> findByName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findByJobAndSalary(String job, Double salary) throws EmployeeException {
		try {			
			List<EmployeeEntity> employeeList=employeeRepository.findByJobAndSalary(job, salary).get();
			if(employeeList.size()!=0) {
				List<Employee> empList = new ArrayList<>();
				employeeList.forEach(employee-> empList.add(modelMapper.map(employee, Employee.class)));
				return empList;
			}else {
				
				throw new EmployeeException("No employees in the database with the specified job and salary");
			}
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public List<Employee> findByJobAndSalaryGreaterThan(String job, Double salary) throws EmployeeException {
		try {			
			List<EmployeeEntity> employeeList=employeeRepository.findByJobAndSalaryGreaterThan(job, salary).get();
			if(employeeList.size()!=0) {
				List<Employee> empList = new ArrayList<>();
				employeeList.forEach(employee-> empList.add(modelMapper.map(employee, Employee.class)));
				return empList;
			}else {
				
				throw new EmployeeException("No employees in the database");
			}
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException {
		try {
			EmployeeEntity employeeEntity = modelMapper.map(employee, EmployeeEntity.class);
			EmployeeEntity employeeEntityReturn =employeeRepository.save(employeeEntity);
			return modelMapper.map(employeeEntityReturn, Employee.class);
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}

	@Override
	public Map<String, Boolean> deleteEmployee(Long id) throws EmployeeException {
		try {
			Optional<EmployeeEntity> employeeEntity=employeeRepository.findById(id);
			
			if(employeeEntity.isPresent()) {
				employeeRepository.delete(employeeEntity.get());
				Map<String,Boolean> statusMap= new HashMap<>();
				statusMap.put("Employee deleted", Boolean.TRUE);
				return statusMap;
			}else {
				throw new EmployeeException("Invalid EmployeeId");
			}
		
		}catch(DataAccessException e) {
			
			throw new EmployeeException(e.getMessage(),e);
		}
	}


}
