package com.adp.spring.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.adp.spring.entity.EmployeeEntity;




@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeEntity,Long>{
	public Optional<EmployeeEntity> findByName(String name);
	public Optional<List<EmployeeEntity>> findByJobAndSalary(String job,Double salary);	
	
//	@Query("select e from Employee e where e.job= :pjob AND e.salary > :psal")
//	public List<Employee> 
//			findByJobAndGreaterThanSalary(@Param("pjob") String job,
//											@Param("psal") Double salary);
	
	@Query("SELECT e FROM EmployeeEntity e WHERE e.job = ?1 AND e.salary > ?2")
    Optional<List<EmployeeEntity>> findByJobAndSalaryGreaterThan(String job, Double salary);
}
