package com.adp.spring.dto;

import java.time.LocalDate;
import java.util.Date;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Employee {
	
    private Long id;
    @Size(min = 3, max = 20)
    private String name;   
    private String job;
    
    private LocalDate hiredate;
    private Double salary;    
   

    

	    
}