package com.ey.spring.security.config;

import static org.springframework.security.config.Customizer.withDefaults;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		http
		.authorizeHttpRequests((authorize) -> authorize
				.anyRequest().authenticated()
				)
		.httpBasic(withDefaults())
		.formLogin(withDefaults());
		
		return http.build();


		
	}



	
	//https://www.baeldung.com/spring-security-5-default-password-encoder
	
	@Bean
    public InMemoryUserDetailsManager userDetailsService() {
        PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
        UserDetails user = User.withUsername("eyuser1")
            .password(encoder.encode("eyuser1"))
            .roles("USER")
            .build();
        
        UserDetails user1 = User.withUsername("eyuser2")
                .password(encoder.encode("eyuser2"))
                .roles("USER")
                .build();
        return new InMemoryUserDetailsManager(user,user1);
    }




}