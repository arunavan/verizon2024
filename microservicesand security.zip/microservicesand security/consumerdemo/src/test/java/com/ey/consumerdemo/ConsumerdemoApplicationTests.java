package com.ey.consumerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
