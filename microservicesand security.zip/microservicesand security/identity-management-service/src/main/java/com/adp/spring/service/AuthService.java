package com.adp.spring.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.adp.spring.dto.UserResponse;
import com.adp.spring.entity.UserInfo;
import com.adp.spring.repository.UserInfoRepository;

@Service
public class AuthService {

    @Autowired
    private UserInfoRepository repository;
    
    @Autowired
    private UserInfoUserDetailsService userInfoUserDetailsService;

   
    @Autowired
    private JwtService jwtService;

    public String saveUser(UserInfo userInfo) {
    	PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
    	userInfo.setName(userInfo.getName());
    	userInfo.setEmail(userInfo.getEmail());
    	userInfo.setPassword(encoder.encode(userInfo.getPassword()));
    	userInfo.setRoles("ROLE"+"_"+ userInfo.getRoles());
    	
        repository.save(userInfo);
        return "User added to the database";
    }

    public String generateToken(String username) {
        return jwtService.generateToken(username);
    }

    public Boolean validateToken(String token ) {
    	UserDetails userDetails = userInfoUserDetailsService.loadUserByUsername(jwtService.extractUsername(token));
        return jwtService.validateToken(token, userDetails);
    }
    
    public UserResponse getUser(String token ) {
    	
    	UserDetails userDetails = userInfoUserDetailsService.loadUserByUsername(jwtService.extractUsername(token));
        if(userDetails != null) {
        	UserInfo userInfo = repository.findByName(userDetails.getUsername()).get();
        	return new UserResponse(userInfo.getName(),userInfo.getEmail(), userInfo.getRoles());
        }else {
        	return null;
        }   	
    	
    }


}