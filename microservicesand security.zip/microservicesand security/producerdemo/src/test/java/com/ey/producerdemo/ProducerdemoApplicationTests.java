package com.ey.producerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
