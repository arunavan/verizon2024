package com.ey.producerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class HelloProducerServiceApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(HelloProducerServiceApplication2.class, args);
	}

}
