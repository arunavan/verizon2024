
import './App.css';
import useForm from './Hooks/useForm';

function App() {

  //Final submit function
  const formLogin = () => {
    console.log("Callback function when form is submitted!");
    console.log("Form Values ", values);
  }
  //Custom hook call
  const {handleChange, values,errors,handleSubmit} = useForm(formLogin);
  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
      <input type="email" name="email" placeholder="E-mail"  onChange={handleChange}   />
      {
        errors.email && <h3>{errors.email}</h3>
      }
      <input minLength='8' type="password" name="password" placeholder="password"  onChange={handleChange}   required/>
      {
        errors.password && <h3>{errors.password}</h3>

      }
      <input type="text" minLength='5' required name="username" placeholder="username"  onChange={handleChange}   />
      {
        errors.username && <h3>{errors.username}</h3>

      }
      <input type="submit" value="Submit" className="submit"  />
      </form>

    </div>
  );
}

export default App;

/*


import { useForm } from "react-hook-form";
//import "./app.css";

const App = () => {
 const { handleSubmit, register, formState: { errors } } = useForm();
 const onSubmit = values => alert(values.email + " " + values.password);

 return (
   <div className="app">
     <form onSubmit={handleSubmit(onSubmit)}>
       <h1>Register</h1>
       <div className="formInput">
         <label>Email</label>
         <input
           type="email"
           {...register("email", {
             required: "Required",
             pattern: {
               value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
               message: "invalid email address"
             }
           })}
         />
         {errors.email && errors.email.message}
       </div>
       <div className="formInput">
         <label>Password</label>
         <input
           type="password"
           {...register("password", {
             required: "Required",
             pattern: {
               value: /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/,
               message: "Password requirements: 8-20 characters, 1 number, 1 letter, 1 symbol."
             }
           })}
         />
         {errors.password && errors.password.message}
       </div>
       <button type="submit">Submit</button>
     </form>
   </div>
 );
};


export default App;

*/