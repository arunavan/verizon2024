package com.verizon.associations.o2m;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.associations.o2o.Student;
import com.verizon.associations.o2o.StudentService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	@PostMapping("/employee")
	public String addEmployee(@RequestBody EmployeeDTO employeeDTO)
	{
		employeeService.addEmployee(employeeDTO);
		return "success";
	}
	
	@GetMapping("/employee")
	public List<EmployeeDTO> getAllEmployees(){
		return employeeService.getAllEmployees();
	}
	
}
	/*
	 {
	       
	        "name": "ramesh141",
	        "salary": 6999,
	        "departmentDto": {
	            "did": 141,
	            "dname": "Infra"
	        }
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    [
    {
        "eid": 1004,
        "name": "ramesh141",
        "salary": 6999,
        "departmentDto": {
            "did": 141,
            "dname": "Infra"
        }
    },
    {
        "eid": 1006,
        "name": "ramesh191",
        "salary": 6999,
        "departmentDto": {
            "did": 191,
            "dname": "Infra"
        }
    },
    {
        "eid": 952,
        "name": "ram",
        "salary": 8999,
        "departmentDto": {
            "did": 101,
            "dname": null
        }
    },
    {
        "eid": 1003,
        "name": "ramesh",
        "salary": 6999,
        "departmentDto": {
            "did": 131,
            "dname": "IT"
        }
    },
    {
        "eid": 1007,
        "name": "kumar",
        "salary": 6999,
        "departmentDto": {
            "did": 192,
            "dname": "Infra"
        }
    },
    {
        "eid": 1008,
        "name": "Arun",
        "salary": 6999,
        "departmentDto": {
            "did": 193,
            "dname": "Infra"
        }
    }
]
	
	*/