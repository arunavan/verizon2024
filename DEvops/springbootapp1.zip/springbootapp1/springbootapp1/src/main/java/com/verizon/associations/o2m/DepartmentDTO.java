package com.verizon.associations.o2m;

public class DepartmentDTO {
	Integer did;
	String dname;
	DepartmentDTO(){
		
	}
	public DepartmentDTO(Integer did, String dname) {
		super();
		this.did = did;
		this.dname = dname;
	}
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	
	

}
