package com.verizon.associations.o2o;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	
	public void  addStudent(Student student) {
		studentDao.save(student);
	}
	
	public List<Student> getAllStudents(){
		return studentDao.findAll();
	}

}
