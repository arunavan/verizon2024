package com.verizon;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;



public interface CustomerRepositoryJPAConvention  {
/*
extends JpaRepository<Customer, Integer> {
	Optional<Customer> findByEmailId(String emailId);

	Optional<Customer> findByEmailIdAndName(String emailId, String name);

	
	List<Customer> findByEmailIdOrName(String emailId, String name);

	List<Customer> findByDateOfBirthBetween(LocalDate fromDate, LocalDate toDate);

	List<Customer> findByDateOfBirthLessThan(LocalDate dateOfBirth);

	List<Customer> findByDateOfBirthGreaterThan(LocalDate dateOfBirth);

	List<Customer> findByDateOfBirthAfter(LocalDate dateOfBirth);

	List<Customer> findByDateOfBirthBefore(LocalDate dateOfBirth);

	List<Customer> findByEmailIdNull();

	List<Customer> findByNameLike(String pattern);

	List<Customer> findByNameOrderByDateOfBirth(String name);

	List<Customer> findByNameOrderByDateOfBirthDesc(String name);
*/
}
