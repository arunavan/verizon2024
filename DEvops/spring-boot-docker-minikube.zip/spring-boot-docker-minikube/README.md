# Related Tutorials

1. [Deploying a Spring Boot App to Kubernetes (Minikube)](https://howtodoinjava.com/devops/deploy-dockerized-spring-boot-app-to-minikube/)