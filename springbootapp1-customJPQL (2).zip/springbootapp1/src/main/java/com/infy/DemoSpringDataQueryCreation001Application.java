package com.infy;
import java.time.LocalDate;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import com.infy.dto.CustomerDTO;
import com.infy.service.CustomerServiceImpl;

@SpringBootApplication
public class DemoSpringDataQueryCreation001Application implements CommandLineRunner {
	
	private static final Log LOGGER = LogFactory.getLog(DemoSpringDataQueryCreation001Application.class);
	@Autowired
	CustomerServiceImpl customerService;
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringDataQueryCreation001Application.class, args);

	}

	public void run(String... args) throws Exception {

		 findByEmailId();
		 findByEmailIdAndName();
		 findByEmailIdOrName();
		 findByDateOfBirthLessThan();
		 findByDateOfBirthGreaterThan();
		 findByDateOfBirthAfter();
		 findByDateOfBirthBefore();
		 findByEmailIdIsNull();
		 findByNameLike();
		 findByNameOrderByDateOfBirth();
		 findByNameOrderByDateOfBirthDesc();
	}

	public void findByEmailId()  throws Exception{
			CustomerDTO customerDTO = customerService.findByEmailId("martin@infy.com");
			System.out.println(customerDTO);
		
	}

	public void findByEmailIdAndName() throws Exception {
			CustomerDTO customerDTO = customerService.findByEmailIdAndName("martin@infy.com", "martin");
			System.out.println(customerDTO);
	}

	public void findByEmailIdOrName()  throws Exception{

			List<CustomerDTO> customerDTOs = customerService.findByEmailIdOrName("martin@infy.com", "martin");

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
				
			});

	}

	

	public void findByDateOfBirthLessThan() throws Exception {
		
			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthLessThan(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByDateOfBirthGreaterThan()  throws Exception{
		

			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthGreaterThan(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByDateOfBirthAfter() throws Exception{
		
			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthAfter(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByDateOfBirthBefore() throws Exception{
		

			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthBefore(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByEmailIdIsNull() throws Exception{
		
			List<CustomerDTO> customerDTOs = customerService.findByEmailIdNull();

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByNameLike() throws Exception {
		
			List<CustomerDTO> customerDTOs = customerService.findByNameLike("j%");

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	public void findByNameOrderByDateOfBirth()throws Exception  {
		
			List<CustomerDTO> customerDTOs = customerService.findByNameOrderByDateOfBirth("martin");

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

	void findByNameOrderByDateOfBirthDesc() throws Exception {
		
			List<CustomerDTO> customerDTOs = customerService.findByNameOrderByDateOfBirthDesc("martin");

			customerDTOs.forEach(customerDTO -> {
				System.out.println(customerDTO);
			});
	}

}
