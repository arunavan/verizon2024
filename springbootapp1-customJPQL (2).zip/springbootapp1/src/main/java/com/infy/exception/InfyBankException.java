package com.infy.exception;

public class InfyBankException extends Exception {
	
	public InfyBankException(String message) {
		super(message);
	}
}
